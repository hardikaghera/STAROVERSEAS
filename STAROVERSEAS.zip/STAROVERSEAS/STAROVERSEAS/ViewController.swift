//
//  ViewController.swift
//  STAROVERSEAS
//
//  Created by hardik aghera on 12/01/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit
import SDWebImage


class TableViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    var imageURL = [String]()
    var eonArray: [eonObject] = []
    
    struct eonObject {
        
        var productName: String
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        eonArray.append(eonObject(productName: "EON PATCH FITTING SYSTEM"))
        eonArray.append(eonObject (productName: "EON SHOWER HINGES"))
        eonArray.append(eonObject (productName: "EON GLASS CONNECTORS"))
        eonArray.append(eonObject (productName: "EON POINT FIXED GLASS CONNECTOR"))
        eonArray.append(eonObject (productName: "EON SHOWER KNIGHT HEAD ACCESSORIES"))
        eonArray.append(eonObject (productName: "EON SLIDING SYSTEMS"))
        eonArray.append(eonObject (productName: "EON SPIDER FITTINGS "))
        eonArray.append(eonObject (productName: "EON DOOR CONTROL SYSTEM "))
        eonArray.append(eonObject (productName: "EON GLASS DOOR HANDLES"))
        eonArray.append(eonObject(productName: "EON SHELF HOLDERS"))
        eonArray.append(eonObject (productName: "EON PVC SEALS"))
        eonArray.append(eonObject (productName: "EON RAILING ACCESSORIES"))
        
        
        
        
        
        
        
        
        
        imageURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image.jpg?alt=media&token=99911b04-acb9-4655-b148-9cff65b80707",
                    "https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image1.jpg?alt=media&token=1bd1125e-c488-4985-83f4-213bbcc0d18e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image2.jpg?alt=media&token=b41719ff-c25d-46c5-917b-484791a56e36","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image3.jpg?alt=media&token=89d9c2e8-2b9c-4dbd-8972-a70bbdfa04a9","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image4.jpg?alt=media&token=9e1bb73c-49df-42df-ae2b-adc19c3e6e2c","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image5.jpg?alt=media&token=847d4a0b-9375-4bfa-b332-9619d59a6a96","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image6.jpg?alt=media&token=cc33a57f-6ee4-49b2-aea2-1e225a576d73","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image7.jpg?alt=media&token=b2e552e4-10e3-4f66-acae-102040c20687","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image8.jpg?alt=media&token=f15328ec-722e-4b87-8ff3-472ee8d9e790","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image9.jpg?alt=media&token=75a977f1-d63b-45e1-983b-486cd0f72fa7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image23.jpg?alt=media&token=a52987cc-ef08-40ad-a0ca-91d623b33c28","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/main%20image10.jpg?alt=media&token=a0ac3ab5-5db3-493f-b979-a386abcc6334"]
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! MyTableViewCell
        let MyimageView = cell.viewWithTag(1) as! UIImageView        
        MyimageView.sd_setImage(with: URL(string: imageURL[indexPath.row]), placeholderImage: #imageLiteral(resourceName: "Image"), options: [.continueInBackground,.progressiveDownload])
        cell.productName.text = eonArray[indexPath.row].productName
        cell.viewButton.tag = indexPath.row
        cell.viewButton.addTarget(self, action:#selector(buttonClick(_button:)), for: .touchUpInside)
        
        
        
        return cell
    }

      func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return imageURL.count
    }
    
    
    func buttonClick(_button:UIButton) {
        
        let str =  String(format:"%d",_button.tag)
        self.performSegue(withIdentifier: "image_segue", sender:str)
        
        
        
    }
    
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "image_segue" {
            
            let obj = segue.destination as! ProductTableViewController
           obj.eon = sender as! String
            
            
        }
        
    }
    

    
}

