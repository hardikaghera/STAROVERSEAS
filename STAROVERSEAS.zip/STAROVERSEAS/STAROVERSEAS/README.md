# STAROVERSEAS

#ABOUT THE APP

Staroverseas is the name of company making hardware fitting for glass components.
Here i have made the list of various products with there name and price in a tableview.
It gives information about the product and contact detail of the staroverseas is also provided.

#PERFORMANCE AND MAKING

This app is build in xcode 8 and swift 3.
All the images of the product are stored in firebase storage and from there it is retrieved.
Images are maintained in the tableview using SDWebImages.
App performance is upto to the mark and till now there is no bug.

