//
//  MyTableViewCell.swift
//  STAROVERSEAS
//
//  Created by hardik aghera on 12/01/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    @IBOutlet weak var MyimageView: UIImageView!
    @IBOutlet weak var productName: UILabel!
    
    @IBOutlet weak var viewButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
