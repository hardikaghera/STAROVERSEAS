//
//  ProductViewController.swift
//  STAROVERSEAS
//
//  Created by hardik aghera on 12/01/17.
//  Copyright © 2017 hardik aghera. All rights reserved.
//

import UIKit
import SDWebImage

class ProductTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var productURL = [String]()
    
    
    struct ProductObject  {
        var SubProductName: String
        var ProductPrice : String
    }
    
    var productarray : [ProductObject] = []
    var eon:String = ""
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if eon == "0"
        {
            
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/1.jpg?alt=media&token=afc7f20f-ba2c-490b-a924-6bbfc1a8acd3","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/2.jpg?alt=media&token=4775d3b4-6a65-494b-9812-1b7d59cf3614","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/3.jpg?alt=media&token=b875a3a8-ba4d-4354-aa3e-0469426fc24d","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/04.jpg?alt=media&token=f2442e78-8a8c-4614-9a77-cafd28e91b88","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/05.jpg?alt=media&token=cf3509d6-3639-4858-9d28-0c111a2a72e5","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/06.jpg?alt=media&token=a1358823-9395-4667-94a5-7c9c31751f10","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/07.jpg?alt=media&token=1a8f9746-35a0-4595-8836-b4f4c13f2a98","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/08.jpg?alt=media&token=6de041a3-3248-4f9d-9e4d-db9ca1a750a6","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/09.jpg?alt=media&token=72aa7149-c7e3-4a51-8c7e-f2afe0af2e12","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/10.jpg?alt=media&token=7f326acc-8655-4e75-812d-128ea5646db8","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/11.jpg?alt=media&token=65ecf658-c0cd-4853-a634-4821839af557"]
            
            
            
            productarray.append(ProductObject(SubProductName: "BOTTOM PATCH EPT-10" , ProductPrice: "INR 700"))
            
            productarray.append(ProductObject(SubProductName: "TOP PATCH EPT-20" , ProductPrice: "INR 700"))
            
            productarray.append(ProductObject(SubProductName: "OVER PANEL PATCH EPT-30" , ProductPrice: "INR 900"))
            
            productarray.append(ProductObject(SubProductName: "OVER PANEL SIDE PANEL PATCH WITH PIVOT (BIG- L) EPT-40" , ProductPrice: "INR 1450"))
            
            productarray.append(ProductObject(SubProductName: "OVER PANEL SIDE PANEL PATCH (PATCH - L) EPT - 50" , ProductPrice: "INR 1110"))
         
            productarray.append(ProductObject(SubProductName: "PATCH LOCK EPT-60" , ProductPrice: "INR 2100"))
            
            productarray.append(ProductObject(SubProductName: "TOP PIVOT EPT-70" , ProductPrice: "INR 200"))
    
            productarray.append(ProductObject(SubProductName: "CONNECTOR PATCH (WALL MOUNT)     EPT-650" , ProductPrice: "INR 900"))
            
            productarray.append(ProductObject(SubProductName: "CONNECTOR PATCH FOR TWO GLASS      EPT-650" , ProductPrice: "INR 550"))
            
            productarray.append(ProductObject(SubProductName: "CONNECTOR PATCH (WALL MOUNT)     EPT-505" , ProductPrice: "INR 1000"))
            
            productarray.append(ProductObject(SubProductName: "BOTTOM BEARING PIVOT EPT-80" , ProductPrice: "INR 550"))
            
            
            
        }
        
        
        if eon == "1"
        {
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F1.jpg?alt=media&token=24ba4e4b-3cdc-47a5-8de9-97a9147c2364","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F2.jpg?alt=media&token=b8671f76-e0b9-457d-92d1-3d659022e45c","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F3.jpg?alt=media&token=864b36a3-24c2-4930-8feb-3d59445a1f85","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F4.jpg?alt=media&token=b342433d-ec02-4b97-acb6-db1cd89fcb51","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F5.jpg?alt=media&token=ed5b7098-d464-4c4f-aca0-2f3c41d17b8a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F6.jpg?alt=media&token=8283fe95-be2a-4c6c-8d4d-d04fb628e883","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F7.jpg?alt=media&token=0826ffd9-d239-4f5f-ad8a-851e9dbf351a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F8.jpg?alt=media&token=f90c66d7-310f-42f6-b77b-1607a72ef62f","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F9.jpg?alt=media&token=5e8e75ed-e521-49f9-a2b8-5562e21b29e1","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F10.jpg?alt=media&token=3c0235d4-65cd-4828-9a93-73316234afa3","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F11.jpg?alt=media&token=197dc006-02ee-4971-a5d2-895712c764fa","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F12.jpg?alt=media&token=0fbcc1b3-05b6-4e8a-845b-490dbde789e0","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F13.jpg?alt=media&token=b8d9a1e3-7fd0-4643-96fc-00471e949b80","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F14.jpg?alt=media&token=f5ede139-7cc2-40ad-8fe6-bee49799467a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F15.jpg?alt=media&token=7ff7e314-d16d-4cea-8c82-dfd7adff04c9","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F16.jpg?alt=media&token=17bf3def-269b-4be7-ab6a-7c5caa236b97","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F17.jpg?alt=media&token=623e3705-7793-4b0b-bc7c-260604b5a99a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F18.jpg?alt=media&token=00745631-4007-4f40-9afe-c71141b1b647","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%201%2F19.jpg?alt=media&token=293951d5-0107-4059-af38-567a56722b2c"]
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS HINGE ESH-B1" , ProductPrice: "INR 1756"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-180 DEGREE HINGE ESH-B2" , ProductPrice: "INR 2922"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-90 DEGREE HINGE ESH-B3" , ProductPrice: "INR 3022"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-135 DEGREE HINGE ESH-B4" , ProductPrice: "INR 2922"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX HINGE ESH-B5" , ProductPrice: "INR 1756"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS OFFSET HINGE ESH-B6" , ProductPrice: "INR 1800"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS HINGE ESH-1" , ProductPrice: "INR 1756"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-180 DEGREE HINGE ESH-2" , ProductPrice: "INR 2922"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-90 DEGREE HINGE ESH-3" , ProductPrice: "INR 3022"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-135 DEGREE HINGE ESH-4" , ProductPrice: "INR 2922"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX HINGE ESH-5" , ProductPrice: "INR 1756"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS OFFSET HINGE ESH-6" , ProductPrice: "INR 1800"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS O GLASS HINDE FOR TWO DOORS ESH-7" , ProductPrice: "INR 5000"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS HINGE ESH-Z1" , ProductPrice: "INR 815"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-180 DEGREE HINGE ESH-Z2" , ProductPrice: "INR 1125"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS -90 DEGREE HINGE ESH-Z3" , ProductPrice: "INR 1312"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-135 DEGREE HINGE ESH-Z4" , ProductPrice: "INR 1350"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX HINGE ESH-Z5" , ProductPrice: "INR 815"))
            
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS OFFSET HINGE ESH-Z6" , ProductPrice: "INR 850"))
            
            
            
        }
        
        
        if eon == "2"
            
        {
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F1.jpg?alt=media&token=2ee0e0cb-9af7-48b9-9d76-df3af479a0ed","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F2.jpg?alt=media&token=8c8a8aac-93a3-4b2a-b8b4-68fe01fdf982","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F3.jpg?alt=media&token=152a04d5-2055-458a-8ba2-be34fa161afc","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F4.jpg?alt=media&token=179ff496-3949-43df-93a6-9065937aec31","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F5.jpg?alt=media&token=f239166d-aaf4-4295-9bab-fa9a214788f9","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F6.jpg?alt=media&token=b9f96ad6-e727-43d1-b716-6c864c92c9d7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F7.jpg?alt=media&token=9f31045f-9bcc-49bb-abe3-c64a8c09510b","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F8.jpg?alt=media&token=edc7b38b-ed51-4ad5-8048-71cc22aac5a3","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F9.jpg?alt=media&token=15763547-e534-47a5-bc5e-e76152118ea7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F10.jpg?alt=media&token=ede2c952-10c1-4611-9aba-9ee91298247c","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%202%2F11.jpg?alt=media&token=c69d8f54-69f9-49c4-82c1-0aa5f6659c38"]
            
            
            
            productarray.append(ProductObject(SubProductName: "FIX CONNECTOR EGC-1" , ProductPrice: "INR 300"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS-90 DEGREE CONNECTOR EGC-2" , ProductPrice: "INR 490"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-90 DEGREE CONNECTOR EGC-3" , ProductPrice: "INR 625"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-180 DEGREE CONNECTOR EGC-4" , ProductPrice: "INR 600"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-135 DEGREE CONNECTOR EGC-5" , ProductPrice: "INR 600"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX CONNECTOR EGCS-1" , ProductPrice: "INR 200"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS-90 DEGREE CONNECTOR EGCS-2" , ProductPrice: "INR 300"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-90 DEGREE CONNECTOR EGCS-3" , ProductPrice: "INR 450"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-180 DEGREE CONNECTOR EGCS-4" , ProductPrice: "INR 400"))
            
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS-135 DEGREE CONNECTOR EGCS-5" , ProductPrice: "INR 400"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX CONNECTOR(CUT SIZE) EGCS-6" , ProductPrice: "INR 225"))
            
            
            
            
        }
        
        
        
        if eon == "3"
            
        {
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%203%2F1.jpg?alt=media&token=25878106-8511-45f6-bb3c-40e64df72f43","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%203%2F2.jpg?alt=media&token=92a30cb1-a33f-4b13-ad1b-4b5d1f6ff165","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%203%2F3.jpg?alt=media&token=0afc320c-9cc2-4e58-a807-defb0f591a3b","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%203%2F4.jpg?alt=media&token=94bc10e6-487c-4d5a-96a5-3cc3ca6751c3"]
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS CONNECTOR(ADJUSTABLE) SIZE: 52.5/60/82/103MM EPF-1" , ProductPrice: "INR 1100/1150/1200/1300"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS CONNECTOR (FIX) SIZE: 75/103MM EPF-1A" , ProductPrice: "INR 1100/1300"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS CONNECTOR(ADJUSTABLE) SIZE: 52.5/60/82/103MM EPF-2" , ProductPrice: "INR 1100/1150/1200/1300"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO GLASS CONNECTOR(ADJUSTABLE WITH FIN) SIZE: 52.5/60/82/103 EPF-2A" , ProductPrice: "INR 2500/2700/2900/3300"))
            
        
            
        }
        
        
        if eon == "4"
        {
            
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F1.jpg?alt=media&token=2bc0821e-ee25-4ffd-ac72-596007ed6593","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F2.jpg?alt=media&token=fa7e5d4d-b5a2-4b0f-aaf2-33dcb98cef53","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F3.jpg?alt=media&token=a827b62f-1942-4a6e-b6fc-9a78969dd0d9","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F4.jpg?alt=media&token=0583abb0-538f-4cef-870e-a8bed1f87cd5","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F5.jpg?alt=media&token=c733b87f-f642-47ff-8c24-28e29aaf71c2","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F6.jpg?alt=media&token=6dade9ac-d644-4183-92ec-78502350e7ed","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F7.jpg?alt=media&token=53541510-6c45-448d-a3d6-bd86211873af","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F8.jpg?alt=media&token=df2a801b-166f-4688-a43c-723195a5b4c7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F9.jpg?alt=media&token=fecd3f68-643a-456e-a02d-9302ebd44008","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F10.jpg?alt=media&token=69f8ac50-2e2e-497e-b5d2-175910487d9f","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F11.jpg?alt=media&token=aa9b6018-bb27-4d20-8c6e-264bb47757f2","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%204%2F12.jpg?alt=media&token=7f5e4600-c2ab-4ef6-828b-c2640eb9ff9a"]
            
            productarray.append(ProductObject(SubProductName: "WALL TO PIPE CONNECTOR(⌀19MM) EKH-1" , ProductPrice: "INR 270"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO PIPE CONCIL CONNECTOR(⌀19MM) EKH-1A" , ProductPrice: "INR 800"))
            
            
            productarray.append(ProductObject(SubProductName: "PIPE TO GLASS CONNECTOR(⌀19MM) EKH-2" , ProductPrice: "INR 400"))
            
            
            productarray.append(ProductObject(SubProductName: "PIPE TO GLASS CONNECTOR(⌀19MM) EKH-2A" , ProductPrice: "INR 500"))
            
            
            productarray.append(ProductObject(SubProductName: "PIPE TO PIPE CONNECTOR(⌀19MM) EKH-3" , ProductPrice: "INR 590"))
            
            
            productarray.append(ProductObject(SubProductName: "THREE WAY PIPE CONNECTOR(⌀19MM) EKH-4" , ProductPrice: "INR 590"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO TRACK CONNECTOR ESS-405" , ProductPrice: "INR 425"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO TRACK CONNECTOR('H'CLAMP) EKH-5" , ProductPrice: "INR 560"))
            
            
            productarray.append(ProductObject(SubProductName: "TRACK TO TRACK CONNECTOR('F'CLAMP) EKH-6" , ProductPrice: "INR 680"))
            
            
            productarray.append(ProductObject(SubProductName: "RECTANGLE TRACK(10*30MM) ESS-444" , ProductPrice: "NR 300/RFT"))
            
            
            productarray.append(ProductObject(SubProductName: "ROUND PIPE EKH-555" , ProductPrice: "INR 300/RFT 270/RFT"))
            
            
            productarray.append(ProductObject(SubProductName: "DOOR STOPPER(HALF ROUND) EKH-7" , ProductPrice: "INR 200"))
            
        
            
            
        }
        
        if eon == "5"
        {
         
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F1.jpg?alt=media&token=a393853f-aa7d-49eb-bff7-2f072ba4a88f","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F2.jpg?alt=media&token=99381159-fe14-4a67-a60b-43303f7aa54e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F3.jpg?alt=media&token=1b9a54ff-1614-48c6-87e9-d177f2225cc0","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F4.jpg?alt=media&token=6ca78bfd-53cd-40a2-bd64-7d32e1b4ca4a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F5.jpg?alt=media&token=81090b4c-55bc-45b5-8a3b-13a1bd43b991","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F6.jpg?alt=media&token=60ac8b20-9068-41dd-afe0-5f6b68b229fc","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F7.jpg?alt=media&token=3a97a5d1-e493-461b-be7b-70fa8feee423","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F8.jpg?alt=media&token=6272a872-d20f-402b-8ad2-ab2aeda0662a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F9.jpg?alt=media&token=54d7ffd2-0742-4a5d-a30a-d014f4cbe25e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F10.jpg?alt=media&token=6707ffd6-ac4d-42db-b23e-059feec703dc","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F11.jpg?alt=media&token=fdafe9c7-7e0f-4444-a83a-c6c312fb8c17","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F12.jpg?alt=media&token=fed7e215-3af4-49eb-a062-f3de0a20bcc8","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%205%2F13.jpg?alt=media&token=a492347c-5147-4ec0-aecb-b572a634f9d0"]
            
            
            
            productarray.append(ProductObject(SubProductName: "SLIDING ROLLER ESS-401" , ProductPrice: "INR 2200"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS SUPPORTER ESS-402" , ProductPrice: "INR 900"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS TO TRACK CONNECTOR ESS-403" , ProductPrice: "INR 650"))
            
            
            productarray.append(ProductObject(SubProductName: "END STOP ESS-404" , ProductPrice: "INR 490"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO TRACK CONNECTOR ESS-404" , ProductPrice: "INR 425"))
            
            
            productarray.append(ProductObject(SubProductName: "FLOOR GUIDE ESS-406" , ProductPrice: "INR 950"))
            
            
            productarray.append(ProductObject(SubProductName: "SLIDING ROLLER(BIG FLANGE) ESS-901-B" , ProductPrice: "INR 1800"))
            
            
            productarray.append(ProductObject(SubProductName: "SLIDING ROLLER(SMALL FLANGE) ESS-901-S" , ProductPrice: "INR 1500"))
            
            
            productarray.append(ProductObject(SubProductName: "FLOOR GUIDE(OVAL TYPE) ESS-902" , ProductPrice: "INR 525"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO TRACK CONNECTOR('L'CLAMP) ESS-903" , ProductPrice: "INR 400"))
            
            
            productarray.append(ProductObject(SubProductName: "END STOP ESS-904" , ProductPrice: "INR 350"))
            
            
            productarray.append(ProductObject(SubProductName: "SINGLE SLIDING DOOR TRACK ESS-998" , ProductPrice: "NR 275/RFT"))
            
            
            productarray.append(ProductObject(SubProductName: "SLIDING TRACK(1-FIX,1-DOOR) ESS-999" , ProductPrice: "INR 360/RFT"))
            
            
            
        }
        
        if eon == "6"
        {
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F1.jpg?alt=media&token=2d2a001b-05c6-411d-8723-6687469c18a8","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F2.jpg?alt=media&token=d3d809fb-d119-4edc-9cc2-8605e983bd60","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F3.jpg?alt=media&token=0f96e44b-7755-43fa-b0b0-b61adbb41e9e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F4.jpg?alt=media&token=c84ab5ec-14a9-4e94-903b-16186013b65d","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F5.jpg?alt=media&token=35e25220-321e-4984-ae49-c84a28f75d93","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F6.jpg?alt=media&token=d8284cbe-97cb-40ec-8482-308b7fe9350a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F7.jpg?alt=media&token=459d40a2-7eac-430e-8214-e784a7800cf5","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F8.jpg?alt=media&token=0f2cb46c-6e74-4620-a7dd-9796b7c90e69","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F9.jpg?alt=media&token=afdee5d7-8677-4d94-af7a-1ddb52c675c6","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F10.jpg?alt=media&token=d9c1b3b5-1ff5-4269-9e6a-b22ddbed686b","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F11.jpg?alt=media&token=27a68aeb-81ff-469d-b9f5-7ee439a82185","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F12.jpg?alt=media&token=f263d1c8-4a05-475f-8aab-7f5a47560c24","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F13.jpg?alt=media&token=56eb6a9c-69b7-4140-9ef4-52f25d831002","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F14.jpg?alt=media&token=b7143292-7c4f-458a-9a09-ed986671c414","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F15.jpg?alt=media&token=73a5f043-073f-4b45-a7ab-56f581f53e43","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F16.jpg?alt=media&token=5898d83b-0aab-4fe9-ae41-e0560b579409","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F17.jpg?alt=media&token=511f7630-1181-421c-b5a3-8a46c9cc61a6","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F18.jpg?alt=media&token=7a1bf46f-217e-4a6c-856d-ea6f33dcfea4","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F19.jpg?alt=media&token=4886ab16-503a-418a-a079-0b4e0f8c84cf","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F20.jpg?alt=media&token=18f1862d-0d6a-40e9-81a6-a9a8f660bcab","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F21.jpg?alt=media&token=06ba753f-baa2-4d86-9e8c-c9835882bda8","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%206%2F22.jpg?alt=media&token=5c9964c1-b999-4bf2-904e-21980b3b8fc7"]
            
            
            
            productarray.append(ProductObject(SubProductName: "1-WAY SPIDER POINT TYPE ESF-1" , ProductPrice: "INR 1183/1315"))
            
            
            productarray.append(ProductObject(SubProductName: "2-WAY SPIDER POINT TYPR-180 DEGREE ESF-2" , ProductPrice: "INR 1479/1644"))
            
            
            productarray.append(ProductObject(SubProductName: "3-WAY SPIDER POINT TYPE ESF-3" , ProductPrice: "INR 2484/2760"))
            
            
            productarray.append(ProductObject(SubProductName: "4-WAY SPIDER POINT TYPE ESF-4" , ProductPrice: "INR 3269/3633"))
            
            
            productarray.append(ProductObject(SubProductName: "2-WAY SPIDER POINT TYPE-90 DEGREE ESH-5" , ProductPrice: "INR 1859/2066"))
            
            
            productarray.append(ProductObject(SubProductName: "1-WAY SPIDER FIN TYPE ESF-1F" , ProductPrice: "INR 1130/1250"))
            
            
            productarray.append(ProductObject(SubProductName: "2-WAY SPIDER FIN TYPE ESF-2F" , ProductPrice: "INR 2259/2511"))
            
            
            productarray.append(ProductObject(SubProductName: "4-WAY SPIDER FIN TYPE ESF-4F" , ProductPrice: "INR 3479/3866"))
            
            
            productarray.append(ProductObject(SubProductName: "2-WAY SPIDER FIN TYPE-90 DEGREE ESF-5F" , ProductPrice: "INR 1740/1950"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX ROUTEL(⌀50MM) ERF-1" , ProductPrice: "INR 815"))
            
            
            productarray.append(ProductObject(SubProductName: "ARTICULATED ROUTEL(⌀45MM) ERF-2" , ProductPrice: "INR 777"))
            
            
            productarray.append(ProductObject(SubProductName: "ARTICULATED ROUTEL(⌀60MM) ERF-3" , ProductPrice: "INR 1006"))
            
            
            productarray.append(ProductObject(SubProductName: "FIX COUNTERSUNK ROUTEL ERF-4" , ProductPrice: "INR 711"))
            
            
            productarray.append(ProductObject(SubProductName: "POINT TYPE SPIDER STUD ERF-5" , ProductPrice: "INR 1150"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO GLASS CONNECTOR ECF-1" , ProductPrice: "INR 1700"))
            
            
            productarray.append(ProductObject(SubProductName: "ROD TO GLASS CONNECTOR ECF-2" , ProductPrice: "INR 1500"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL TO ROD CONNECTOR ECF-3" , ProductPrice: "INR 1000"))
            
            
            productarray.append(ProductObject(SubProductName: "WALLL TO GLASS-90 DEGREE CONNECTOR ECF-4" , ProductPrice: "INR 3000"))
            
            
            productarray.append(ProductObject(SubProductName: "ROD TO GLASS CONNECTOR ECF-5" , ProductPrice: "INR 2600"))
            
            
            productarray.append(ProductObject(SubProductName: "WALL CONNECTOR FOR ROD ECF-6" , ProductPrice: "INR 1400"))
            
            
            productarray.append(ProductObject(SubProductName: "THREADED ROD CONNECTOR ECF-7" , ProductPrice: "INR 1200"))
            
            
            productarray.append(ProductObject(SubProductName: "CONNECTING ROD ECF-8" , ProductPrice: "INR INR 500/RFT 700/RFT"))
            
            
            
        }
        
        if eon == "7"
        {
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%207%2F1.jpg?alt=media&token=08e1acce-18ff-46c3-b831-5458cdb71b73","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%207%2F2.jpg?alt=media&token=189cda56-a115-492b-a79b-d73593503a3b","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%207%2F3.jpg?alt=media&token=ec42aa87-c1a9-417b-82ec-076347a8132e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%207%2F4.jpg?alt=media&token=ed1f3b6f-9058-4e7c-b61c-5f786d5c801c"]
            
            productarray.append(ProductObject(SubProductName: "SINGLE CYLINDER FLOOR SPRING(WT.CAPACITY 80-KG) EDCS-1" , ProductPrice: "INR 3300"))
            
            
            productarray.append(ProductObject(SubProductName: "DOUBLE CYLINDER FLOOR SPRING(WT.CAPACITY 120-KG) EDCS-2" , ProductPrice: "INR 5250"))
            
            
            productarray.append(ProductObject(SubProductName: "WOODEN ACCESSORIES SET(TOP,BOTTOM,PIVOT) EDCS-3" , ProductPrice: "INR 600"))
            
            
            productarray.append(ProductObject(SubProductName: "HYDRAULIC PATCH EDCS-4" , ProductPrice: "INR 1000"))
        
        }
        
        if eon == "8"
        {
            
         productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%208%2F1.jpg?alt=media&token=ba75b725-d33e-463b-8953-9982933e843a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%208%2F2.jpg?alt=media&token=24b8b5d0-e12a-4193-bc19-ffc68e653681","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%208%2F3.jpg?alt=media&token=2ac1a099-e92c-4c87-bc3f-85d023fb8293","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%208%2F4.jpg?alt=media&token=d8d3206b-5865-4c4b-a7aa-ee1eebca7a41","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%208%2F5.jpg?alt=media&token=047c75db-377f-4ad1-90a7-2ac4a161dbf9","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%208%2F6.jpg?alt=media&token=ef47021f-bad6-4375-bbcd-f885c1d273b6"]
            
            productarray.append(ProductObject(SubProductName: "H-TYPE EDH-H" , ProductPrice: "INR 772 TO 7852"))
            
            
            productarray.append(ProductObject(SubProductName: "D-TYPE EDH-D" , ProductPrice: "INR 655 TO 2305"))
            
            
            productarray.append(ProductObject(SubProductName: "Q-TYPE(SH-TYPE) EDH-Q" , ProductPrice: "INR 1760 TO 2112"))
            
            
            productarray.append(ProductObject(SubProductName: "S-TYPE EDH-S" , ProductPrice: "INR 1400 TO 1662"))
            
            
            productarray.append(ProductObject(SubProductName: "SHOWER HANDLE EDH-SH" , ProductPrice: "INR 1767 TO 1892"))
            
            
            productarray.append(ProductObject(SubProductName: "LOCK HANDLE(1500MM) EDH-LH" , ProductPrice: "IINR 13125"))
            
            
    
            
        }
        
        if eon == "9"
        {
            
          productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%209%2F1.jpg?alt=media&token=407a9682-ed8d-454d-9f58-5cb3f172ead0","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%209%2F2.jpg?alt=media&token=116b86b8-7a6f-4359-a06b-002abc6befe4","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%209%2F3.jpg?alt=media&token=ea0b7728-a6f9-4016-b571-4027c3cfd031","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%209%2F4.jpg?alt=media&token=d2be522f-3870-4f72-91ba-ac2e3a73ef00","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%209%2F5.jpg?alt=media&token=9cff167f-3a8c-44ad-a9b8-fd349a905ed8","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%209%2F6.jpg?alt=media&token=6f6c6440-de06-45d3-b3e7-3a0b379b829d"]
            
            
             productarray.append(ProductObject(SubProductName: "WALL TO GLASS HOLDER EBSH-1" , ProductPrice: "INR 190"))
            
            
             productarray.append(ProductObject(SubProductName: "GLASS WITH VERTICAL GLASS HOLDER EBSH-2" , ProductPrice: "INR 320"))
            
            
             productarray.append(ProductObject(SubProductName: "TWO GLASS CONNECTOR WITH VERTICAL GLASS EBSH-3" , ProductPrice: "INR 370"))
            
            
             productarray.append(ProductObject(SubProductName: "WALL TO GLASS HOLDER EBSH-4" , ProductPrice: "INR 260"))
            
             productarray.append(ProductObject(SubProductName: "GLASS WITH VERTICAL GLASS HOLDER EBSH-5" , ProductPrice: "INR 380"))
            
            
             productarray.append(ProductObject(SubProductName: "TWO GLASS CONNECTOR WITH VERTICAL GLASS EBSH-6" , ProductPrice: "INR 450"))
            
        }
        
        if eon == "10"
        {
          productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2010%2F1.jpg?alt=media&token=7e5ac262-f520-4ed7-8a50-f4a23c07d6e6","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2010%2F2.jpg?alt=media&token=81c6d9e2-e94d-42a8-83ad-08376650e861","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2010%2F3.jpg?alt=media&token=58b701d0-47da-471d-bdf6-48f4fbf580bc","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2010%2F4.jpg?alt=media&token=d459c504-a9e8-4018-bf6d-b3fb4c4980e7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2010%2F5.jpg?alt=media&token=3834bf6b-9a7f-4928-9782-68fbe0602eac"]
            
            
            productarray.append(ProductObject(SubProductName: "D-PROFILE EPVC-1" , ProductPrice: "INR 200"))
            
            
            productarray.append(ProductObject(SubProductName: "H-PROFILE EPVC-2" , ProductPrice: "INR 200"))
            
            
            productarray.append(ProductObject(SubProductName: "CENTER PROFILE EPVC-3" , ProductPrice: "INR 200"))
            
            
            productarray.append(ProductObject(SubProductName: "F-PROFILE EPVC-4" , ProductPrice: "INR 200"))
            
            
            productarray.append(ProductObject(SubProductName: "MAGNETIC PROFILE EPVC-5" , ProductPrice: "INR 1100"))
            
        }
        
        if eon == "11"
        {
            
            productURL = ["https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F1.jpg?alt=media&token=05cde922-d4ac-47ca-bec3-4f378c2fa197","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F2.jpg?alt=media&token=3efaac38-41bb-4129-a949-6476138abc36","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F3.jpg?alt=media&token=49e8c430-1b7e-40ab-994e-0616747fb8e7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F4.jpg?alt=media&token=bb8c8b8c-6b68-4d61-afd2-9d82bf25a94c","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F5.jpg?alt=media&token=a0e4cce9-ec13-43a1-8274-ec8be611a6c9","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F6.jpg?alt=media&token=42a25507-246f-4e1c-b765-7b44817798cc","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F7.jpg?alt=media&token=cb5822d5-80d6-4ddd-b60f-13a47d2c2a30","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F8.jpg?alt=media&token=5c82e506-3e6b-4ffd-be84-4251accc7c5e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F9.jpg?alt=media&token=0363acf7-13bf-4046-81f4-dafbddeb42e7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F10.jpg?alt=media&token=aec2d8d5-71b2-48fd-acd9-385efb78a69b","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F11.jpg?alt=media&token=48e229fa-578d-49ee-a28f-428aa90b249e","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F12.jpg?alt=media&token=4f83d5fd-3a93-43a3-b88e-122c317567fb","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F13.jpg?alt=media&token=cbeab86c-c8c7-4b3f-86b1-141fedbe7caa","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F14.jpg?alt=media&token=031dcf5b-955c-468e-a932-557b68b9b447","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F15.jpg?alt=media&token=af6110f9-61b6-431f-9d27-8873342cc71a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F16.jpg?alt=media&token=5f498509-622e-407a-a582-6e055d109170","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F17.jpg?alt=media&token=2fbebd02-c44e-4ae9-bd4d-b056ca2519fe","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F18.jpg?alt=media&token=0f12a14c-9a7b-4554-918a-785ab6724139","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F19.jpg?alt=media&token=3975f9c2-fa1e-4a0f-b22f-6b8a3b00d9ed","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F20.jpg?alt=media&token=edd04fcb-dd76-43c2-8554-ad007b90deae","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F21.jpg?alt=media&token=def8cc18-4c92-44a7-85c4-5dea5859696b","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F22.jpg?alt=media&token=d0fa3af7-e785-40b8-90f7-f02672689888","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F23.jpg?alt=media&token=53a38ce1-4c61-4cd0-9e7d-cdb5bf9e9807","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F24.jpg?alt=media&token=b36c018e-67d1-42c5-81d1-1f40636fa206","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F25.jpg?alt=media&token=a09d4c5a-e495-4b68-9e1f-c8b90315286a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F26.jpg?alt=media&token=563f720b-08b0-4c3b-9417-23e79c0269d7","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F27.jpg?alt=media&token=e1582166-b3fe-45b6-b704-9f749daa889a","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F28.jpg?alt=media&token=61e9fae1-7993-47bd-b432-e69775864674","https://firebasestorage.googleapis.com/v0/b/staroverseas-92c36.appspot.com/o/eon%2011%2F29.jpg?alt=media&token=763867dd-cfde-4c1a-81e8-47164d53c7fd"]
            
            
            
            productarray.append(ProductObject(SubProductName: "RAILING BOLT ERA-1" , ProductPrice: "INR 1075"))
            
            
            productarray.append(ProductObject(SubProductName: "SQUARE MODULAR BEND(SIZE 38MM,50MM) ERA-2" , ProductPrice: "INR 1000/1875"))
            
            
            productarray.append(ProductObject(SubProductName: "ROUND MODULAR BEND(SIZE 38MM,50MM) ERA-3" , ProductPrice: "INR 900/1750"))
            
            
            productarray.append(ProductObject(SubProductName: "ROUND SPIGOT WITH FLANGE(⌀-50MM) ERA-S-1" , ProductPrice: "INR 4625"))
            
            
            productarray.append(ProductObject(SubProductName: "ROUND SPIGOT WITHOUT FLANGE(SIZE ⌀40MM,50MM) ERA-S-2" , ProductPrice: "INR 3000/3375"))
            
            
            productarray.append(ProductObject(SubProductName: "SQUARE SPIGOT WITH FLANGE(10840MM) ERA-S-3" , ProductPrice: "INR 3000"))
            
            
            productarray.append(ProductObject(SubProductName: "SQUARE SPIGOT WITHOUT FLANGE(10840MM) ERA-S-4" , ProductPrice: "INR 1400"))
            
            
            productarray.append(ProductObject(SubProductName: "DECORATIVE SPIGOT TRIANGULAR TYPE ERA-S-5" , ProductPrice: "INR 7000"))
            
            
            productarray.append(ProductObject(SubProductName: "DECORATIVE SPIGOT ERA-S-6" , ProductPrice: "INR 900"))
            
            
            productarray.append(ProductObject(SubProductName: "ROUND TAPERED SPIGOT ERA-S-7" , ProductPrice: "INR 4700"))
            
            
            productarray.append(ProductObject(SubProductName: "ELBOW-90 DEGREE(SIZE 38MM,50MM) ERA-4" , ProductPrice: "INR 900/1750"))
            
            
            productarray.append(ProductObject(SubProductName: "RAILING BRAKET OVAL ERA-5" , ProductPrice: "INR 850"))
            
            
            productarray.append(ProductObject(SubProductName: "DECORATIVE HANDRAIL BRACKET ERA-H-1" , ProductPrice: "INR 1150"))
            
            
            productarray.append(ProductObject(SubProductName: "ADJUSTABLE HANDRAIL BRACKET ERA-H-2" , ProductPrice: "INR 900"))
            
            
            productarray.append(ProductObject(SubProductName: "C-TYPE HANDRAIL BRACKET ERA-H-3" , ProductPrice: "INR 1000"))
            
            
            productarray.append(ProductObject(SubProductName: "O-TYPE HANRAIL BRACKET ERA-H-4" , ProductPrice: "INR 1375/1600"))
            
            
            productarray.append(ProductObject(SubProductName: "L-TYPE HANDRAIL BRACKET ERA-H-5" , ProductPrice: "INR 560"))
            
            
            productarray.append(ProductObject(SubProductName: "HANDRAIL BRACKET ERA-6" , ProductPrice: "INR 810"))
            
            
            productarray.append(ProductObject(SubProductName: "RAILING SPIDER FIX ERA-7" , ProductPrice: "INR 1650"))
            
            
            productarray.append(ProductObject(SubProductName: "END CAP ERA-8" , ProductPrice: "INR 450/720"))
            
            
            productarray.append(ProductObject(SubProductName: "THROUGH BARRELS(SIZE: 10*50,12*40,10*40) ERA-9" , ProductPrice: "INR 350/387/375"))
            
            
            productarray.append(ProductObject(SubProductName: "RAILING SPIDER UNIVERSAL ERA-10" , ProductPrice: "INR 2150"))
            
            
            productarray.append(ProductObject(SubProductName: "RAILING TEE ERA-11" , ProductPrice: "INR 250"))
            
            
            productarray.append(ProductObject(SubProductName: "RAILING TEE ERA-12" , ProductPrice: "INR 175"))
            
            
            productarray.append(ProductObject(SubProductName: "GLASS BRACKET ERA-13" , ProductPrice: "INR 600"))
            
            
            productarray.append(ProductObject(SubProductName: "BALUSTRADE ERA-B-1" , ProductPrice: "INR 5625"))
            
            
            productarray.append(ProductObject(SubProductName: "BALUSTRADE ERA-B-2" , ProductPrice: "INR 2365"))
            
            
            productarray.append(ProductObject(SubProductName: "BALUSTRADE ERA-B-3" , ProductPrice: "INR 2300"))
            
            
            productarray.append(ProductObject(SubProductName: "BALUSTRADE ERA-B-4" , ProductPrice: "INR 2250"))
            
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return productarray.count
        
        
    }
    
       func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductTableViewCell
        let ProductImage = cell.viewWithTag(1) as! UIImageView
        ProductImage.sd_setImage(with: URL(string: productURL[indexPath.row]), placeholderImage: #imageLiteral(resourceName: "Image"), options: [.continueInBackground,.progressiveDownload])
        
        cell.SubProductName.text = productarray[indexPath.item].SubProductName
        cell.ProductPrice.text = productarray[indexPath.item].ProductPrice
       
        return cell
        
    }
    
    
    
}
